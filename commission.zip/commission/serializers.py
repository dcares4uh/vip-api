from rest_framework import serializers
from .models import CommissionByCategories, CommissionSettings

class CommissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = CommissionByCategories
        fields = '__all__'

class CommissionSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = CommissionSettings
        fields = '__all__'

